class HomeController < ApplicationController
  
  def index
    respond_to do |format|
      format.html # index.html.erb
      format.xml  { head :ok }
    end
  end

end
