class Role < ActiveRecord::Base
  
end